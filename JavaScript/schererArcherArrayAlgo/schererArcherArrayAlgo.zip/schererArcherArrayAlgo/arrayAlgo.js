//Algo 1 //
var testArr = [6,3,5,1,2,4];
var sum= 0;
var num= 0;

for(var i= 0; i < testArr.length; i++) {
    num= testArr[i];
    sum+=num;
    console.log("Num " + num, "Sum " + sum)
}

//Algo 2//

var testArr = [6,3,5,1,2,4];
var newVal = 0;

for(var i= 0; i < testArr.length; i++) {
    newVal = i * testArr[i];
    testArr[i] = newVal
}
console.log(testArr)