//Print odds 1-20//
for(var i= 1; i <=20; i++) {
    if(i % 2 != 0){
        console.log(i);
    }
}

//Sum and print 1-5//

var sumNums =0;
for(var num = 1; num<= 5; num++) {
    sumNums += num;
    console.log(num);
    console.log(sumNums);
}